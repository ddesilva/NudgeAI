#!/bin/bash
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
xattr -dr com.apple.quarantine "${HERE}/NudgeAI.app" || true
open "${HERE}/NudgeAI.app"
